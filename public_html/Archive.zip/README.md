EACHe sua república
===================

English
-------

EACHe sua república is a collaborative project developed to help USP's (University of Sao Paulo) students to find friendships around EACH's (School of Arts, Sciences and Humanities) campus, located in east of Sao Paulo (Brazil). 

### Creators ###

* Leonardo Rocha
* Lucas Proni
* Renan Souza de Freitas
* Thiago Kobashigawa
* Vitor Hoffman

### Roadmap ###

* User: edit and delete friendships
* User: edit profile
* Login/registration via Facebook
* Single page for friendships
* Public transportation route

Português
---------

EACHe sua república é um projeto colaborativo criado para auxiliar os alunos da USP a encontrar repúblicas na região da EACH (Escola de Artes, Ciências e Humanidades), situada na zona leste de São Paulo.

### Criadores ###

* Leonardo Rocha
* Lucas Proni
* Renan Souza de Freitas
* Thiago Kobashigawa
* Vitor Hoffman

### Planos futuros ###

* Usuário: editar e deletar repúblicas
* Usuário: editar perfil
* Login/cadastro via Facebook
* Página única para repúblicas
* Rota de transporte público
